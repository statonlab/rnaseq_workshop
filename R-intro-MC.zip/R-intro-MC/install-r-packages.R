pkgs = c('plyr', 'dplyr')
install.packages(pkgs, repos = "http://cran.us.r-project.org")